CREATE DATABASE IF NOT EXISTS skill_academy;
USE skill_academy;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('student', 'instructor', 'admin') DEFAULT 'student',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT
);

CREATE TABLE courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    instructor_id INT NOT NULL,
    category_id INT NOT NULL,
    thumbnail VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (instructor_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
);

CREATE TABLE enrollments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    progress INT DEFAULT 0,
    enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

CREATE TABLE payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    payment_status ENUM('pending', 'completed', 'failed') DEFAULT 'completed',
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

-- Passwords should be hashed in real app
-- Given hash corresponds to 'password123' generated with bcrypt
INSERT INTO users (name, email, password, role) VALUES
('Admin User', 'admin@skillacademy.com', '$2a$10$tZ2R//w07H3Iok0b.QByK.xS99Mv0R3g0O26r.F2jK35l/2uM0jB6', 'admin'),
('Instructor John', 'john@skillacademy.com', '$2a$10$tZ2R//w07H3Iok0b.QByK.xS99Mv0R3g0O26r.F2jK35l/2uM0jB6', 'instructor'),
('Student Jane', 'jane@skillacademy.com', '$2a$10$tZ2R//w07H3Iok0b.QByK.xS99Mv0R3g0O26r.F2jK35l/2uM0jB6', 'student');

INSERT INTO categories (name, description) VALUES
('Web Development', 'Learn to build websites and web apps'),
('Data Science', 'Learn Python, Machine Learning, and standard Data Science toolkits'),
('Design', 'UI/UX and Graphic Design');

INSERT INTO courses (title, description, price, instructor_id, category_id, thumbnail) VALUES
('Fullstack Web Bootcamp', 'Master web development from scratch', 49.99, 2, 1, 'web-bootcamp.jpg'),
('Python for Data Science', 'Data structures, Pandas, and Scikit-learn', 59.99, 2, 2, 'data-science.jpg');

INSERT INTO enrollments (student_id, course_id, progress) VALUES
(3, 1, 10);

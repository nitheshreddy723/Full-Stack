# Full-Stack Skill Learning Academy Marketplace

A complete full-stack dynamic web application for an online learning marketplace with secure authentication, role-based access control, and stunning glassmorphism modern UI.

## Tech Stack
- Frontend: HTML5, CSS3 (Vanilla + Custom Properties), Vanilla JavaScript
- Backend: Node.js, Express.js
- Database: MySQL (via XAMPP)

## Project Initialization
### Prerequisites
1. Installed XAMPP (for MySQL database)
2. Installed Node.js & npm

### Database Setup
1. Start MySQL from the XAMPP control panel.
2. Open phpMyAdmin (`http://localhost/phpmyadmin`) or your MySQL CLI.
3. Import the `database.sql` script located in the root folder to create the `skill_academy` database and sample data.
*(Sample users include `admin@skillacademy.com`, `john@skillacademy.com` (Instructor), `jane@skillacademy.com` (Student). The default password is `password123`).*

### Backend Setup
1. Navigate to the `backend` folder via terminal:
   ```bash
   cd backend
   ```
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the Express API server:
   ```bash
   npm start
   # or node server.js
   ```
   *The server will run on `http://localhost:5000`.*

### Frontend Setup
1. Simply serve the `frontend` folder using any local HTTP server, e.g., using `Live Server` in VSCode, or using `npx serve frontend`.
2. Open `index.html` in your browser.

## Features
- Dynamic premium user interface showcasing smooth gradients and UI glassmorphism.
- Complete public marketplace catalog.
- User Authentication (Login, Register).
- Role-based Dashboards (Student, Instructor, Admin).
- Full API for course creation and student enrollment logic.

// api.js - Centralized API logic
const API_URL = 'http://localhost:5000/api';

const api = {
    async request(endpoint, method = 'GET', body = null) {
        const token = localStorage.getItem('token');
        const headers = {
            'Content-Type': 'application/json'
        };

        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }

        const config = {
            method,
            headers
        };

        if (body) {
            config.body = JSON.stringify(body);
        }

        try {
            const response = await fetch(`${API_URL}${endpoint}`, config);
            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || 'API Error');
            }
            return data;
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    },

    auth: {
        login: (credentials) => api.request('/auth/login', 'POST', credentials),
        register: (userData) => api.request('/auth/register', 'POST', userData),
        getMe: () => api.request('/auth/me')
    },

    courses: {
        getAll: () => api.request('/courses'),
        getById: (id) => api.request(`/courses/${id}`),
        create: (courseData) => api.request('/courses', 'POST', courseData),
        update: (id, courseData) => api.request(`/courses/${id}`, 'PUT', courseData),
        delete: (id) => api.request(`/courses/${id}`, 'DELETE')
    },

    enrollments: {
        enroll: (course_id) => api.request('/enrollments', 'POST', { course_id }),
        getMy: () => api.request('/enrollments/my')
    },

    admin: {
        getAnalytics: () => api.request('/admin/analytics')
    }
};

window.api = api;

// app.js - Global UI Logic
document.addEventListener('DOMContentLoaded', () => {
    // Add Google Fonts for modern typography
    const link = document.createElement('link');
    link.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap';
    link.rel = 'stylesheet';
    document.head.appendChild(link);

    updateNavbar();
});

function updateNavbar() {
    const user = JSON.parse(localStorage.getItem('user'));
    const navLinks = document.getElementById('nav-links');

    if (!navLinks) return;

    if (user) {
        let dashboardLink = '';
        if (user.role === 'admin') dashboardLink = 'dashboard-admin.html';
        else if (user.role === 'instructor') dashboardLink = 'dashboard-instructor.html';
        else dashboardLink = 'dashboard-student.html';

        navLinks.innerHTML = `
            <li><a href="index.html">Marketplace</a></li>
            <li><a href="${dashboardLink}">Dashboard</a></li>
            <li><a href="#" onclick="logout(event)" style="color: var(--danger)">Logout (${user.name})</a></li>
        `;
    } else {
        navLinks.innerHTML = `
            <li><a href="index.html">Marketplace</a></li>
            <li><a href="login.html" class="btn btn-primary">Login</a></li>
        `;
    }
}

function logout(e) {
    if (e) e.preventDefault();
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = 'login.html';
}

function showMessage(elementId, message, type = 'error') {
    const el = document.getElementById(elementId);
    if (!el) return;
    el.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
    setTimeout(() => { el.innerHTML = ''; }, 5000);
}

function getImageUrl(thumbnail, title = '') {
    if (thumbnail && thumbnail !== 'default.jpg') {
        if (thumbnail.startsWith('http')) return thumbnail;
        return `assets/${thumbnail}`;
    }

    // If no thumbnail or default.jpg, return a unique image based on the course title
    if (title) {
        const seed = encodeURIComponent(title.replace(/\s+/g, '-').toLowerCase());
        return `https://picsum.photos/seed/${seed}/800/600`;
    }

    return 'assets/default.jpg';
}

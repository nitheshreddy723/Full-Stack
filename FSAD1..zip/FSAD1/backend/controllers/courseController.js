const db = require('../config/db');

exports.getAllCourses = async (req, res) => {
    try {
        const [courses] = await db.query(
            `SELECT c.*, u.name as instructor_name, cat.name as category_name 
             FROM courses c 
             JOIN users u ON c.instructor_id = u.id 
             JOIN categories cat ON c.category_id = cat.id`
        );
        res.json(courses);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

exports.getCourseById = async (req, res) => {
    try {
        const [courses] = await db.query(
            `SELECT c.*, u.name as instructor_name, cat.name as category_name 
             FROM courses c 
             JOIN users u ON c.instructor_id = u.id 
             JOIN categories cat ON c.category_id = cat.id 
             WHERE c.id = ?`,
            [req.params.id]
        );
        if (courses.length === 0) return res.status(404).json({ message: 'Course not found' });
        res.json(courses[0]);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

exports.createCourse = async (req, res) => {
    const { title, description, price, category_id, thumbnail } = req.body;
    try {
        const [result] = await db.query(
            'INSERT INTO courses (title, description, price, instructor_id, category_id, thumbnail) VALUES (?, ?, ?, ?, ?, ?)',
            [title, description, price, req.user.id, category_id, thumbnail]
        );
        res.status(201).json({ id: result.insertId, title, message: 'Course created successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

exports.deleteCourse = async (req, res) => {
    try {
        const [course] = await db.query('SELECT * FROM courses WHERE id = ?', [req.params.id]);
        if (course.length === 0) return res.status(404).json({ message: 'Course not found' });

        if (req.user.role !== 'admin' && course[0].instructor_id !== req.user.id) {
            return res.status(403).json({ message: 'Not authorized to delete this course' });
        }

        await db.query('DELETE FROM enrollments WHERE course_id = ?', [req.params.id]);
        await db.query('DELETE FROM courses WHERE id = ?', [req.params.id]);
        res.json({ message: 'Course deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

exports.updateCourse = async (req, res) => {
    const { title, description, price, category_id, thumbnail } = req.body;
    try {
        const [course] = await db.query('SELECT * FROM courses WHERE id = ?', [req.params.id]);
        if (course.length === 0) return res.status(404).json({ message: 'Course not found' });

        if (req.user.role !== 'admin' && course[0].instructor_id !== req.user.id) {
            return res.status(403).json({ message: 'Not authorized to edit this course' });
        }

        await db.query(
            'UPDATE courses SET title=?, description=?, price=?, category_id=?, thumbnail=? WHERE id=?',
            [title, description, price, category_id, thumbnail, req.params.id]
        );
        res.json({ message: 'Course updated successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

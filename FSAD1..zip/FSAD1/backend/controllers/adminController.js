const db = require('../config/db');

exports.getAnalytics = async (req, res) => {
    try {
        const [[{ total_users }]] = await db.query('SELECT COUNT(*) as total_users FROM users');
        const [[{ total_courses }]] = await db.query('SELECT COUNT(*) as total_courses FROM courses');
        const [[{ total_enrollments }]] = await db.query('SELECT COUNT(*) as total_enrollments FROM enrollments');

        res.json({ total_users, total_courses, total_enrollments });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};
